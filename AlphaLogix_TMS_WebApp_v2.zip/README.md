# AlphaLogix TMS Web App v2

This folder is ready to publish as a static website using GitHub Pages.

## Current business rules
- Dispatcher pay = 10% of gross load revenue
- Driver pay = $0.60 per total dispatched mile
- Total dispatched miles = loaded miles + deadhead miles
- Fuel cost can be linked to loads
- MPG is learned from full-tank fuel logs using odometer readings
- Profitability = gross - dispatcher - driver - fuel - tolls/permits - other expenses

## Publish with GitHub Pages
1. Create a new GitHub repository, e.g. `alphalogix-tms`.
2. Upload every file in this folder to the repository root.
3. In GitHub: Settings -> Pages.
4. Under Build and deployment, choose "Deploy from a branch".
5. Select `main` and `/ (root)`, then Save.
6. GitHub will provide the public website address.

## iPhone
After the site is published:
1. Open the site in Safari.
2. Tap Share.
3. Tap "Add to Home Screen".
4. It will open like an app.

## Important
Version 2 stores data in the browser using localStorage.
That means data persists on that device/browser, but it does NOT yet sync between devices.

The next upgrade for true multi-device operation is a cloud database + user login.
